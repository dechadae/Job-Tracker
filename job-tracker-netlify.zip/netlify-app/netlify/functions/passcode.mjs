import { getStore } from "@netlify/blobs";

// Stores only a one-way hash of the passcode, never the passcode itself.
export default async (req) => {
  const store = getStore("job-tracker");

  if (req.method === "GET") {
    const hash = await store.get("passcode-hash", { type: "text" });
    return new Response(JSON.stringify({ hash: hash || null }), {
      headers: { "content-type": "application/json" },
    });
  }

  if (req.method === "POST") {
    let body;
    try {
      body = await req.json();
    } catch (e) {
      return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400 });
    }

    const existing = await store.get("passcode-hash", { type: "text" });
    // Once a passcode is set, it can only be changed by proving the old one,
    // to stop anyone from silently taking over edit access.
    if (existing && body.previousHash !== existing) {
      return new Response(JSON.stringify({ error: "Not authorized to change passcode" }), {
        status: 403,
      });
    }

    await store.set("passcode-hash", body.hash);
    return new Response(JSON.stringify({ ok: true }), {
      headers: { "content-type": "application/json" },
    });
  }

  return new Response("Method not allowed", { status: 405 });
};

export const config = { path: "/api/passcode" };
